/*
 * 菜单类 用来显示主页面菜单
 * 人机交互场所
 */
public class Menu {
    private Menu(){}
    public static void menu()
    {
        
    }
}